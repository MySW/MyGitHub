//
//  WYLoginViewController.h
//  Notes
//
//  Created by 钱钱 on 14-6-16.
//  Copyright (c) 2014年 guoming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WYLoginView.h"

@interface WYLoginViewController : UIViewController

@property (nonatomic, retain) WYLoginView *loginView;  // 根视图

@end
