//
//  WYLostPasswordViewController.h
//  Notes
//
//  Created by 钱钱 on 14-6-17.
//  Copyright (c) 2014年 guoming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WYLostPasswordViewController.h"
#import "WYLostPassword.h"

@interface WYLostPasswordViewController : UIViewController

@property (nonatomic, retain) WYLostPassword *findPasswordView; // 找回密码视图

@end
