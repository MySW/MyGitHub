//
//  WYRegisterViewController.h
//  Notes
//
//  Created by 钱钱 on 14-6-16.
//  Copyright (c) 2014年 guoming. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WYRegisterView.h"

@interface WYRegisterViewController : UIViewController

@property (nonatomic, retain) WYRegisterView *registerView; //注册视图

@end
